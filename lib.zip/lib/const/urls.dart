
const String baseUrl='https://theravenstyle.com/api';
const String baseImage='https://theravenstyle.com/public/';


const kLoginUrl='$baseUrl/login';
const kOrdersUrl='$baseUrl/orders';
const kClientsTransactionsUrl='$baseUrl/clients/transactions';
const kClientUrl='$baseUrl/clients';
const kGetFieldsForCreateClientUrl='$baseUrl/clients/create';
const kGetAllQuotationsUrl='$baseUrl/quotations';
const kStoreQuotationUrl='$baseUrl/quotations';
const kDeleteQuotationUrl='$baseUrl/quotations';
const kUpdateQuotation='$baseUrl/quotations/update';
const kGetFieldsForCreateQuotationUrl='$baseUrl/quotations/create';
const kGetAllProductsUrl='$baseUrl/items';
const kAddProductUrl='$baseUrl/items';
const kDeleteProductUrl='$baseUrl/items';
const kGetFieldsForCreateProductUrl='$baseUrl/items/create';
const kGetCategoriesUrl='$baseUrl/categories';
const kStoreCategoryUrl='$baseUrl/categories';
const kEditCategoryUrl='$baseUrl/categories';//id
const kDeleteCategoryUrl='$baseUrl/categories';//id
const kUploadProductImageUrl='$baseUrl/imgs';
const kUpdateProductImageUrl='$baseUrl/imgs/update';
const kDeleteProductImageUrl='$baseUrl/imgs/delete';
const kExchangeRateUrl='$baseUrl/config/exchange_rate';
const kGetCurrenciesUrl='$baseUrl/config/currencies';
const kAddCurrenciesUrl='$baseUrl/config/currencies';
const kUpdateCurrenciesUrl='$baseUrl/config/currencies';//id
const kDeleteCurrenciesUrl='$baseUrl/config/currencies';//id
const kAddDiscountsUrl='$baseUrl/config/discounts';
const kGetDiscountsUrl='$baseUrl/config/discounts';
const kDeleteDiscountsUrl='$baseUrl/config/discounts';
const kUpdateDiscountsUrl='$baseUrl/config/discounts';
const kAddTaxationGroupUrl='$baseUrl/config/tax-groups';
const kUpdateTaxationGroupUrl='$baseUrl/config/tax-groups';//id
const kDeleteTaxationGroupUrl='$baseUrl/config/tax-groups';//id
const kAddRateUrl='$baseUrl/config/tax-groups/rates';//id
const kEditQuantityUrl='$baseUrl/items/quantities';
const kEditPriceUrl='$baseUrl/items/prices';
const kAddCashedMethodUrl='$baseUrl/config/cashing-methods';
const kDeleteCashedMethodUrl='$baseUrl/config/cashing-methods';
const kUpdateItemUrl='$baseUrl/items/update';
const kUpdateCashingMethodUrl='$baseUrl/config/cashing-methods'; //id
const kCreateWarehouseUrl='$baseUrl/warehouses';
const kGetWarehouseUrl='$baseUrl/warehouses';
const kDeleteWarehouseUrl='$baseUrl/warehouses';
const kUpdateWarehouseUrl='$baseUrl/warehouses'; //id
const kGetReplenishmentsDataForCreateUrl='$baseUrl/replenishments/create';
const kGetQTyOfItemInWarehouseUrl='$baseUrl/items/warehouseQty';
const kAddReplenishmentsUrl='$baseUrl/replenishments';
const kGetReplenishmentsUrl='$baseUrl/replenishments';
const kCreateTransferOutUrl='$baseUrl/transfers/create';
const kAddTransferOutUrl='$baseUrl/transfers';
const kGetTransfersUrl='$baseUrl/transfers';
const kTransferInUrl='$baseUrl/transfers/transfer-in';
const kCreatePosUrl='$baseUrl/pos/create';
const kGetPosUrl='$baseUrl/pos';
const kAddPosUrl='$baseUrl/pos';
const kDeletePosUrl='$baseUrl/pos';
const kUpdatePosUrl='$baseUrl/pos';
const kUsersUrl='$baseUrl/users';
const kCreateUsersUrl='$baseUrl/users/create';
const kGetGroupsUrl='$baseUrl/itemGroups';
const kStoreGroupUrl='$baseUrl/itemGroups';
const kUpdateGroupUrl='$baseUrl/itemGroups/update';
const kDeleteGroupUrl='$baseUrl/itemGroups/delete';
const kRoleUrl='$baseUrl/roles';
const kUpdateRoleUrl='$baseUrl/roles/update';//id
const kDeleteRoleUrl='$baseUrl/roles/delete';//id
const kGetAllRolesAndPermissionsUrl='$baseUrl/roles';
const kUpdateRolesAndPermissionsUrl='$baseUrl/roles/update-roles-permissions';
const kSessionsUrl='$baseUrl/sessions';
const kSessionsReportUrl='$baseUrl/sessions/report';
const kWasteReportUrl='$baseUrl/items/report';
const kOpenSessionIdUrl='$baseUrl/sessions/current-session';
const kGetInventoryDataUrl='$baseUrl/inventory/get-inventory-data';
const kInventoryUrl='$baseUrl/inventory';
const kSettingsUrl='$baseUrl/settings';
const kTasksUrl='$baseUrl/tasks';
const kPriceListUrl='$baseUrl/pricelists';
const kGetPriceListItemsUrl='$baseUrl/pricelists/items';
const kCreatePriceListUrl='$baseUrl/pricelists/create';
const kUpdatePriceListUrl='$baseUrl/pricelists/update';




const kGetCountriesUrl='https://countriesnow.space/api/v0.1/countries/population';
const kGetCitiesOfASpecifiedCountryUrl='https://countriesnow.space/api/v0.1/countries/cities';


