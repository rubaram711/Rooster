import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rooster_app/Controllers/comboController.dart';
import 'package:rooster_app/Widgets/dialog_drop_menu.dart';
import 'package:rooster_app/Widgets/reusable_add_card.dart';
import 'package:rooster_app/Widgets/reusable_text_field.dart';
import 'package:rooster_app/Widgets/table_title.dart';
import '../../../Controllers/home_controller.dart';
import '../../../Controllers/products_controller.dart';
import '../../../Widgets/dialog_title.dart';
import '../../../const/Sizes.dart';
import '../../../const/colors.dart';
import '../../Widgets/reusable_more.dart';

class Combo extends StatefulWidget {
  const Combo({super.key});
  @override
  State<Combo> createState() => _ComboState();
}

class _ComboState extends State<Combo> {
  final HomeController homeController = Get.find();
  final ProductController productController = Get.find();
  final TextEditingController comboNameController = TextEditingController();
  final TextEditingController comboCodeController = TextEditingController();
  final TextEditingController comboPriceController = TextEditingController();
  final TextEditingController comboCurrenceController = TextEditingController();
  final TextEditingController comboMainDescriptionController =
      TextEditingController();
  ComboController comboController = Get.find();
  String selectedCurrency = '';
  addNewItem() {
    setState(() {
      comboController.listViewLengthInCombo =
          comboController.listViewLengthInCombo + comboController.increment;
    });
    Widget p = const ReusableItemRow();
    comboController.addToRowsInListViewInCombo(p);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductController>(
      builder: (cont) {
        return Container(
          color: Colors.white,
          width: MediaQuery.of(context).size.width * 0.85,
          height: MediaQuery.of(context).size.height * 0.95,
          margin: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
          // padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  DialogTitle(text: 'create_new_combo'.tr),
                  gapW100,
                  InkWell(
                    onTap: () {
                      Get.back();
                    },
                    child: CircleAvatar(
                      backgroundColor: Primary.primary,
                      radius: 15,
                      child: const Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
              gapH16,
              Text(
                "Combo's Name",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 17.00,
                ),
              ),
              gapH10,
              ReusableTextField(
                onChangedFunc: () {},
                validationFunc: () {},
                hint: " ",
                isPasswordField: false,
                textEditingController: comboNameController,
              ),
              gapH10,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  DialogTextField(
                    textEditingController: comboPriceController,
                    text: 'combo_code'.tr,
                    rowWidth: MediaQuery.of(context).size.width * 0.30,
                    textFieldWidth: MediaQuery.of(context).size.width * 0.20,
                    validationFunc: (value) {
                      if (value.isEmpty) {
                        return 'required_field'.tr;
                      }
                      return null;
                    },
                  ),

                  DialogNumericTextField(
                    validationFunc: () {},
                    text: "Price",
                    rowWidth: MediaQuery.of(context).size.width * 0.30,
                    textFieldWidth: MediaQuery.of(context).size.width * 0.20,
                    textEditingController: comboPriceController,
                  ),
                ],
              ),
              gapH10,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  DialogDropMenu(
                    optionsList: ['usd'.tr, 'lbp'.tr],
                    text: 'currency'.tr,
                    hint: 'usd'.tr,
                    rowWidth: MediaQuery.of(context).size.width * 0.30,
                    textFieldWidth: MediaQuery.of(context).size.width * 0.20,
                    onSelected: (value) {
                      setState(() {
                        selectedCurrency = value;
                      });
                    },
                    controller: comboCurrenceController,
                  ),

                  DialogTextField(
                    validationFunc: () {},
                    text: "Main Description",
                    rowWidth: MediaQuery.of(context).size.width * 0.30,
                    textFieldWidth: MediaQuery.of(context).size.width * 0.20,
                    textEditingController: comboMainDescriptionController,
                  ),
                ],
              ),
              gapH20,
              Column(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: MediaQuery.of(context).size.width * 0.01,
                      vertical: 15,
                    ),
                    decoration: BoxDecoration(
                      color: Primary.primary,
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                    ),
                    child: Row(
                      children: [
                        gapW16,
                        TableTitle(
                          text: 'item_code'.tr,
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.09,
                        ),

                        TableTitle(
                          text: 'description'.tr,
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.32,
                        ),

                        TableTitle(
                          text: 'quantity'.tr,
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.07,
                        ),
                        TableTitle(
                          text: 'unit_price'.tr,
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.07,
                        ),
                        TableTitle(
                          text: '${'disc'.tr}. %',
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.07,
                        ),
                        TableTitle(
                          text: 'total'.tr,
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.07,
                        ),
                        TableTitle(
                          text: '     ${'more_options'.tr}',
                          isCentered: false,
                          width: MediaQuery.of(context).size.width * 0.10,
                        ),
                      ],
                    ),
                  ),
                  //********************************Get Builder For Table Row********************************************* */
                  GetBuilder<ComboController>(
                    builder: (cont) {
                      return Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: MediaQuery.of(context).size.width * 0.01,
                        ),
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(6),
                            bottomRight: Radius.circular(6),
                          ),
                          color: Colors.white,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            //+++++++++++++++++Rows in table With SingleScrollView+++++++++++++++++++++++++++++++
                            SizedBox(
                              height: MediaQuery.of(
                                context,
                              ).size.height *
                                  0.3,
                              child: ListView.builder(
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                padding: const EdgeInsets.symmetric(
                                  vertical: 10,
                                ),
                                itemCount:
                                    cont
                                        .rowsInListViewInCombo
                                        .length, //products is data from back res
                                itemBuilder:
                                    (context, index) => Row(
                                      children: [
                                        cont.rowsInListViewInCombo[index],
                                        SizedBox(
                                          width:
                                              MediaQuery.of(
                                                context,
                                              ).size.width *
                                              0.03,
                                          child: InkWell(
                                            onTap: () {
                                              setState(() {
                                                cont.decrementlistViewLengthInCombo(
                                                  cont.increment,
                                                );
                                                cont.removeFromRowsInListViewInCombo(
                                                  index,
                                                );
                                              });
                                            },
                                            child: Icon(
                                              Icons.delete_outline,
                                              color: Primary.primary,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                              ),
                            ),
                            //++++++++++++++++++++++++++++++++++++++++++++++++
                            gapH10,
                            Row(
                              children: [
                                ReusableAddCard(
                                  text: 'create_new_combo'.tr,
                                  onTap: () {
                                    addNewItem();
                                  },
                                ),
                                gapW32,
                                ReusableAddCard(
                                  text: 'create_append'.tr,
                                  onTap: () {
                                    // addNewItem();
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  //**************************************************************************** */
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class ReusableItemRow extends StatefulWidget {
  const ReusableItemRow({super.key});
  // const ReusableItemRow({super.key, required this.index, required this.info});

  @override
  State<ReusableItemRow> createState() => _ReusableItemRowState();
}

class _ReusableItemRowState extends State<ReusableItemRow> {
  String price = '0', disc = '0', result = '0', quantity = '0';
  final ComboController combocont = Get.find();
  final _formKey = GlobalKey<FormState>();
  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ComboController>(
      builder: (cont) {
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),

          child: Form(
            key: _formKey,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.02,
                  height: 20,
                  margin: const EdgeInsets.symmetric(vertical: 15),
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/images/newRow.png'),
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                DialogDropMenu(
                  optionsList: const [''],
                  text: '',
                  hint: 'item'.tr,
                  rowWidth: MediaQuery.of(context).size.width * 0.07,
                  textFieldWidth: MediaQuery.of(context).size.width * 0.07,
                  onSelected: () {},
                ),
                gapW10,
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.30,
                  child: ReusableTextField(
                    textEditingController: controller, //todo
                    isPasswordField: false,
                    hint: 'lorem ipsumlorem ipsum',
                    onChangedFunc: (val) {},
                    validationFunc: (val) {},
                  ),
                ),
                gapW28,

                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.06,
                  child: ReusableNumberField(
                    textEditingController: controller, //todo
                    isPasswordField: false,
                    hint: '1.00',
                    onChangedFunc: (value) {
                      setState(() {
                        quantity = value;
                      });
                    },
                    validationFunc: (val) {},
                  ),
                ),
                gapW10,
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.06,
                  child: ReusableNumberField(
                    textEditingController: controller, //todo
                    isPasswordField: false,
                    hint: '150.00',
                    onChangedFunc: (val) {
                      setState(() {
                        price = val;
                      });
                    },
                    validationFunc: (val) {},
                  ),
                ),
                gapW10,
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.07,
                  child: ReusableNumberField(
                    textEditingController: controller, //todo
                    isPasswordField: false,
                    hint: '15',
                    onChangedFunc: (val) {
                      setState(() {
                        disc = val;
                      });
                    },
                    validationFunc: (val) {},
                  ),
                ),
                gapW10,
                Container(
                  width: MediaQuery.of(context).size.width * 0.07,
                  height: 47,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black.withAlpha((0.1 * 255).toInt()),
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Center(
                    child: Text(
                      '${int.parse(quantity) * (int.parse(price) - int.parse(disc))}',
                    ),
                  ),
                ),
                gapW28,
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.03,
                  child: ReusableMore(
                    itemsList: [
                      PopupMenuItem<String>(
                        value: '1',
                        onTap: () async {},
                        child: Row(children: [Text('')]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
