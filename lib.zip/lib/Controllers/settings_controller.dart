import 'package:get/get.dart';





class SettingsController extends GetxController {}
