import 'package:flutter/cupertino.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:rooster_app/const/sizes.dart';

class ComboController extends GetxController {
  double listViewLengthInCombo = Sizes.deviceHeight * 0.08;
  double increment = Sizes.deviceHeight * 0.08;

  //double listViewLengthInCombo = 50;

  incrementlistViewLengthInCombo(double val) {
    listViewLengthInCombo = listViewLengthInCombo + val;
    update();
  }

  decrementlistViewLengthInCombo(double val) {
    listViewLengthInCombo = listViewLengthInCombo - val;
    update();
  }

  List<Widget> rowsInListViewInCombo = [];

  removeFromRowsInListViewInCombo(int index) {
    rowsInListViewInCombo.removeAt(index);

    update();
  }

  addToRowsInListViewInCombo(Widget p) {
    rowsInListViewInCombo.add(p);
    update();
  }

  Map<String, Widget> orderLinesComboList = {};
  List<String> itemsCode = [];
  List itemsIds = [];
  bool isCombosInfoFetched = false;
  double totalItems = 0.0;
  String specialDisc = '';
  String globalDisc = ''; // GlobalDisc as int to show it in ui
  String totalCombo = '';

  resetCombo() {
    orderLinesComboList = {};
    rowsInListViewInCombo = [];
    itemsCode = [];
    itemsIds = [];
    isCombosInfoFetched = false;

    totalItems = 0;
    specialDisc = '0';
    globalDisc = '0';

    totalCombo = '0.00';
    update();
  }
}
