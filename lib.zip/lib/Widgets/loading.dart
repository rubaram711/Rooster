import 'package:flutter/material.dart';

Widget loading() {
  return const Center(
    child: CircularProgressIndicator(),
  );
}