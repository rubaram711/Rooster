// style: Theme.of(context).textTheme.headlineMedium,



//      drawer:deviceType ==DeviceScreenType.mobile?Drawer(
//         child: Container(color: Colors.red,),
//       ):null,


//  String? get restorationId => widget.restorationId;

//abed.nahouli@code-caesar.com

//roba-admin@email.com