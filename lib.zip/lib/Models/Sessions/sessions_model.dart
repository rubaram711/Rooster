

class SessionOrder {
  String? orderNumber;
  num? usdTotal;
  num? usdTaxValue;
  num? otherCurrencyTotal;
  num? otherCurrencyTaxValue;
  num? usdDiscountValue;
  num? otherCurrencyDiscountValue;
  num? received;
  List<PaymentDetails>? paymentDetails;
  String? openedAt;
  String? closedAt;
  num? selectedCurrTotal;
  num? selectedCurrTaxTotal;
  num? selectedCurrDiscountTotal;
  num? receivedOtherCurrency;

  SessionOrder(
      {this.orderNumber,
        this.usdTotal,
        this.usdTaxValue,
        this.otherCurrencyTotal,
        this.otherCurrencyTaxValue,
        this.usdDiscountValue,
        this.otherCurrencyDiscountValue,
        this.received,
        this.paymentDetails,
        this.openedAt,
        this.closedAt,
        this.selectedCurrTotal,
        this.selectedCurrTaxTotal,
        this.selectedCurrDiscountTotal,
        this.receivedOtherCurrency});

  SessionOrder.fromJson(Map<String, dynamic> json) {
    orderNumber = json['order_number'];
    usdTotal = json['usd_total'];
    usdTaxValue = json['usd_tax_value'];
    otherCurrencyTotal = json['other_currency_total'];
    otherCurrencyTaxValue = json['other_currency_tax_value'];
    usdDiscountValue = json['usd_discount_value'];
    otherCurrencyDiscountValue = json['other_currency_discount_value'];
    received = json['received'];
    if (json['payment_details'] != null) {
      paymentDetails = <PaymentDetails>[];
      json['payment_details'].forEach((v) {
        paymentDetails!.add( PaymentDetails.fromJson(v));
      });
    }
    openedAt = json['opened_at'];
    closedAt = json['closed_at'];
    selectedCurrTotal = json['selectedCurrTotal'];
    selectedCurrTaxTotal = json['selectedCurrTaxTotal'];
    selectedCurrDiscountTotal = json['selectedCurrDiscountTotal'];
    receivedOtherCurrency = json['receivedOtherCurrency'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['order_number'] = orderNumber;
    data['usd_total'] = usdTotal;
    data['usd_tax_value'] = usdTaxValue;
    data['other_currency_total'] = otherCurrencyTotal;
    data['other_currency_tax_value'] = otherCurrencyTaxValue;
    data['usd_discount_value'] = usdDiscountValue;
    data['other_currency_discount_value'] = otherCurrencyDiscountValue;
    data['received'] = received;
    if (paymentDetails != null) {
      data['payment_details'] =
          paymentDetails!.map((v) => v.toJson()).toList();
    }
    data['opened_at'] = openedAt;
    data['closed_at'] = closedAt;
    data['selectedCurrTotal'] = selectedCurrTotal;
    data['selectedCurrTaxTotal'] = selectedCurrTaxTotal;
    data['selectedCurrDiscountTotal'] = selectedCurrDiscountTotal;
    data['receivedOtherCurrency'] = receivedOtherCurrency;
    return data;
  }
}

class PaymentDetails {
  String? cashingMethod;
  num? usdAmount;
  num? otherCurrencyAmount;

  PaymentDetails(
      {this.cashingMethod, this.usdAmount, this.otherCurrencyAmount});

  PaymentDetails.fromJson(Map<String, dynamic> json) {
    cashingMethod = json['cashing_method'];
    usdAmount = json['usd_amount'];
    otherCurrencyAmount = json['other_currency_amount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cashing_method'] = cashingMethod;
    data['usd_amount'] = usdAmount;
    data['other_currency_amount'] = otherCurrencyAmount;
    return data;
  }
}