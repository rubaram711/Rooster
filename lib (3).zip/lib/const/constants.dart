
List<String> pricesVatConditions = ['Prices are before vat', 'Prices are vat inclusive'];
List<String> vatExemptList = [
  'Printed as "vat exempted"',
  'Printed as "vat 0 % = 0"',
  'No printed ',
];


