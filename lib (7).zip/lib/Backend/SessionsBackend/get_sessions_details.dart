import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../Locale_Memory/save_user_info_locally.dart';
import '../../const/urls.dart';


Future getSessionsDetails(
    {required String fromDate,
      required String endDate,
      required String fromNumber,
      required String toNumber,
      required String currencyId,
      required String singleSessionNumber}) async {
  final uri = Uri.parse(kSessionsReportUrl).replace(queryParameters: {
    'fromDate': fromDate,
    'endDate': endDate,
    'fromNumber': fromNumber,
    'toNumber': toNumber,
    'currencyId': currencyId,
    'singleSessionNumber': singleSessionNumber,
    'isPaginated':'0',
  });
  String token = await getAccessTokenFromPref();
  var response = await http.get(
    uri,
    headers: {
      "Accept": "application/json",
      "Authorization": "Bearer $token"
    },
  );

  var p = json.decode(response.body);
  return p;
  // if(response.statusCode==200) {
  //   return p['data'];
  // }else{
  //   return [];
  // }
}

